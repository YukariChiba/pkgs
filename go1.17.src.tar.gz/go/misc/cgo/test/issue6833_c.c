// Copyright 2013 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

#include "_cgo_export.h"
 
unsigned long long
issue6833Func(unsigned int aui, unsigned long long aull) {
	return GoIssue6833Func(aui, aull);
}
