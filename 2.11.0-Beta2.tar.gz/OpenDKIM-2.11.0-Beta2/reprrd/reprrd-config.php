<?php

###
### Copyright (c) 2012, The Trusted Domain Project.  All rights reserved.
###

# Configuration for RRD-based reputation queries

# root of the RRD table tree
$rrdroot = "/var/db/reprrd";

# depth of directory hashing
$rrddepth = 2;

# timezone (will use 'UTC' if not set)
# $timezone = 'PDT';

?>
