/* ISC license. */

#include <skalibs/gensetdyn.h>

gensetdyn const gensetdyn_zero = GENSETDYN_ZERO ;
