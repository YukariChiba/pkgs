/* ISC license. */

#include <skalibs/genqdyn.h>

genqdyn const genqdyn_zero = GENQDYN_ZERO ;
