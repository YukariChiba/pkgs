/* ISC license. */

#include <skalibs/bigkv.h>

bigkv_t const bigkv_zero = BIGKV_ZERO ;
