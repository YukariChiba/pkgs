/* ISC license. */

#include <skalibs/avlnode.h>

avlnode const avlnode_zero = AVLNODE_ZERO ;
