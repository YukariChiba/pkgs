/* ISC license. */

#include "random-internal.h"

static char const random_oklist_[64] = "ABCDEFGHIJKLMNOPQRSTUVWXYZghijklmnopqrstuvwxyz-_0123456789abcdef" ;
char const *random_oklist = random_oklist_ ;
