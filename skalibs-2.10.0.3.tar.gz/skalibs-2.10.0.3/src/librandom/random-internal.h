/* ISC license. */

#ifndef RANDOM_INTERNAL_H
#define RANDOM_INTERNAL_H

#include <skalibs/surf.h>

extern char const *random_oklist ;
extern int random_fd ;
extern SURFSchedule surf_here ;

#endif
