/* ISC license. */

/* This header is being deprecated */

#include <skalibs/posixplz.h>
