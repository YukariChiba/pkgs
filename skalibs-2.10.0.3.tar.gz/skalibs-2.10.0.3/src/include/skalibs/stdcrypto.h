/* ISC license. */

#ifndef STDCRYPTO_H
#define STDCRYPTO_H

#include <skalibs/rc4.h>
#include <skalibs/md5.h>
#include <skalibs/sha1.h>
#include <skalibs/sha256.h>
#include <skalibs/sha512.h>

#endif
