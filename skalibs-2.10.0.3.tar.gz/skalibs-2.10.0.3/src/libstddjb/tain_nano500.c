/* ISC license. */

#include <skalibs/tai.h>

tain_t const tain_nano500 = TAIN_NANO500 ;
