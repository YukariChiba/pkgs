/* ISC license. */

#include <skalibs/textclient.h>

textclient_t const textclient_zero = TEXTCLIENT_ZERO ;
