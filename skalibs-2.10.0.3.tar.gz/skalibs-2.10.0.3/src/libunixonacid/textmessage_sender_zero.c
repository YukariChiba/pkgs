/* ISC license. */

#include <skalibs/textmessage.h>

textmessage_sender_t const textmessage_sender_zero = TEXTMESSAGE_SENDER_ZERO ;
