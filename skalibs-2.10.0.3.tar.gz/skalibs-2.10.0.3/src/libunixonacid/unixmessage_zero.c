/* ISC license. */

#include <skalibs/unixmessage.h>

unixmessage_t const unixmessage_zero = UNIXMESSAGE_ZERO ;
