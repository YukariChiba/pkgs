/* ISC license. */

/* MT-unsafe */

#include <skalibs/textmessage.h>

textmessage_sender_t textmessage_sender_x_ = TEXTMESSAGE_SENDER_ZERO ;
