/* ISC license. */

#include <skalibs/textmessage.h>

textmessage_receiver_t const textmessage_receiver_zero = TEXTMESSAGE_RECEIVER_ZERO ;
