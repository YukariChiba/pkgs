 /* ISC license. */

#include <skalibs/unixconnection.h>

unixconnection_t const unixconnection_zero = UNIXCONNECTION_ZERO ;
