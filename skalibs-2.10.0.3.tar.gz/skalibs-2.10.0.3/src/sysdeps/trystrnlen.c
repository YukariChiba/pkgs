/* ISC license. */

#include <string.h>

int main (void)
{
  return strnlen("/", 1) ;
}
