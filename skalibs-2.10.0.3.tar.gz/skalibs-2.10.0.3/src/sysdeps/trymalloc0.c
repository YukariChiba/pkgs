/* ISC license */

#include <stdlib.h>

int main (void)
{
  return !malloc(0) ;
}
