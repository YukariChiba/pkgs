/* ISC license. */

#include <fcntl.h>

int dummy = O_DIRECTORY ;
