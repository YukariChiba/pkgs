/* ISC license. */

#include <utmps/utmpx.h>
#include <utmps/utmps.h>
#include "utmps-internal.h"

struct utmpx utmps_utmpx_here ;
utmps utmps_here = UTMPS_ZERO ;
