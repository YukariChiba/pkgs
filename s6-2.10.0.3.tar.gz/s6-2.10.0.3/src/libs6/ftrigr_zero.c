/* ISC license. */

#include <s6/ftrigr.h>

ftrigr_t const ftrigr_zero = FTRIGR_ZERO ;
