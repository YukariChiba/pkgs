/* ISC license. */

#include <s6/ftrigr.h>

ftrigr1_t const ftrigr1_zero = FTRIGR1_ZERO ;
